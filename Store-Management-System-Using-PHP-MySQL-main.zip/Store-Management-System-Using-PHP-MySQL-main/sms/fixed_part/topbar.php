<div class="row align-items-center pb-2">
    <div class="col-sm-1">
        <img src="image/Logo.png" alt="logo" class="img-fluid" style="width:100px;">
    </div>
    <div class="col-sm-7">
        <h1 class="mb-0"><a href="index.php" class="text-primary text-decoration-none">Store Management System </a></h1>
    </div>
    <div class="col-sm-4 justify-content-end">
        <p class=" mb-0 fs-3 text-end text-success fw-bold"><?php echo  $user_first_name ?> <a href="logout.php" class="text-primary text-decoration-none">Logout</a></p>
    </div>
</div>